.
+--- .codespellignore
+--- .codespellrc
+--- .devcontainer
|   +--- devcontainer.json
|   +--- Dockerfile
|   \--- README.md
+--- .git
+--- .gitattributes
+--- .github
|   +--- codex
|   |   +--- home
|   |   |   \--- config.toml
|   |   \--- labels
|   |       +--- codex-attempt.md
|   |       +--- codex-review.md
|   |       +--- codex-rust-review.md
|   |       \--- codex-triage.md
|   +--- codex-cli-login.png
|   +--- codex-cli-permissions.png
|   +--- codex-cli-splash.png
|   +--- demo.gif
|   +--- dependabot.yaml
|   +--- dotslash-config.json
|   +--- ISSUE_TEMPLATE
|   |   +--- 2-bug-report.yml
|   |   +--- 3-docs-issue.yml
|   |   +--- 4-feature-request.yml
|   |   \--- 5-vs-code-extension.yml
|   +--- pull_request_template.md
|   \--- workflows
|       +--- ci.yml
|       +--- cla.yml
|       +--- codespell.yml
|       +--- rust-ci.yml
|       \--- rust-release.yml
+--- .gitignore
+--- .npmrc
+--- .prettierignore
+--- .prettierrc.toml
+--- .vs
|   +--- codex
|   |   +--- CopilotIndices
|   |   |   +--- 17.14.1091.29919
|   |   |   |   +--- CodeChunks.db
|   |   |   |   \--- SemanticSymbols.db
|   |   |   \--- 17.14.1147.5054
|   |   |       +--- CodeChunks.db
|   |   |       +--- CodeChunks.db-shm
|   |   |       +--- CodeChunks.db-wal
|   |   |       +--- SemanticSymbols.db
|   |   |       +--- SemanticSymbols.db-shm
|   |   |       \--- SemanticSymbols.db-wal
|   |   +--- FileContentIndex
|   |   |   +--- 10d0be88-1eaf-450b-9fc6-50a3f0d94714.vsidx
|   |   |   +--- 11a12bc4-76d5-49eb-8bac-cf104fec7c60.vsidx
|   |   |   +--- 1c361553-bcb8-4e86-b3b9-16151447f800.vsidx
|   |   |   +--- 818f7cf9-a5b2-4fed-8b74-149ec259542e.vsidx
|   |   |   +--- 84eda70b-7eb7-4913-ac32-e5c36851623d.vsidx
|   |   |   +--- 91b49aaf-0409-40d0-a062-65693ce2ffe2.vsidx
|   |   |   +--- 9c947b03-6e73-45b1-b3bc-3375d07b0f2a.vsidx
|   |   |   +--- afeeab88-c6a9-4ce9-8800-233288470ee9.vsidx
|   |   |   +--- b7325fed-c9e2-4910-950a-fcad438cec52.vsidx
|   |   |   +--- bb6ddf54-3b7f-4af4-94d8-8fb80072aa21.vsidx
|   |   |   +--- bcdbcd04-c618-4898-8857-cf741f15627c.vsidx
|   |   |   +--- bdd41e09-8dab-4ce8-a890-9eca66847dc5.vsidx
|   |   |   +--- c5656f95-0850-418f-8204-38c82bdf0d82.vsidx
|   |   |   +--- c95d21cd-4d67-4dc7-8cb7-612d15544ebe.vsidx
|   |   |   +--- d7dc5ba5-1bbb-4536-a032-12cfc57b9a06.vsidx
|   |   |   +--- dd96baf2-9bae-44a4-9249-9d3d51153e35.vsidx
|   |   |   \--- e23730a0-75e5-49f4-ad91-bc6c94dcaafe.vsidx
|   |   \--- v17
|   |       +--- .wsuo
|   |       +--- DocumentLayout.backup.json
|   |       +--- DocumentLayout.json
|   |       \--- workspaceFileList.bin
|   +--- ProjectSettings.json
|   +--- slnx.sqlite
|   +--- slnx.sqlite-journal
|   \--- VSWorkspaceState.json
+--- .vscode
|   +--- extensions.json
|   +--- launch.json
|   \--- settings.json
+--- AGENTS.md
+--- CHANGELOG.md
+--- ci
|   \--- mcp-gates.md
+--- cliff.toml
+--- codex-cli
|   +--- .dockerignore
|   +--- .gitignore
|   +--- bin
|   |   \--- codex.js
|   +--- Dockerfile
|   +--- package.json
|   +--- package-lock.json
|   +--- README.md
|   \--- scripts
|       +--- build_container.sh
|       +--- init_firewall.sh
|       +--- install_native_deps.sh
|       +--- README.md
|       +--- run_in_container.sh
|       +--- stage_release.sh
|       \--- stage_rust_release.py
+--- codex-main-20250913-105725.tar.gz
+--- codex-rs
|   +--- .gitignore
|   +--- ansi-escape
|   |   +--- Cargo.toml
|   |   +--- README.md
|   |   \--- src
|   |       \--- lib.rs
|   +--- apply-patch
|   |   +--- apply_patch_tool_instructions.md
|   |   +--- Cargo.toml
|   |   +--- src
|   |   |   +--- lib.rs
|   |   |   +--- main.rs
|   |   |   +--- parser.rs
|   |   |   +--- seek_sequence.rs
|   |   |   \--- standalone_executable.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       \--- suite
|   |           +--- cli.rs
|   |           \--- mod.rs
|   +--- arg0
|   |   +--- Cargo.toml
|   |   \--- src
|   |       \--- lib.rs
|   +--- Cargo.lock
|   +--- Cargo.toml
|   +--- chatgpt
|   |   +--- Cargo.toml
|   |   +--- README.md
|   |   +--- src
|   |   |   +--- apply_command.rs
|   |   |   +--- chatgpt_client.rs
|   |   |   +--- chatgpt_token.rs
|   |   |   +--- get_task.rs
|   |   |   \--- lib.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       +--- suite
|   |       |   +--- apply_command_e2e.rs
|   |       |   \--- mod.rs
|   |       \--- task_turn_fixture.json
|   +--- cli
|   |   +--- Cargo.toml
|   |   +--- src
|   |   |   +--- debug_sandbox.rs
|   |   |   +--- exit_status.rs
|   |   |   +--- lib.rs
|   |   |   +--- login.rs
|   |   |   +--- main.rs
|   |   |   \--- proto.rs
|   |   \--- tests
|   |       \--- precedence.rs
|   +--- clippy.toml
|   +--- common
|   |   +--- Cargo.toml
|   |   +--- README.md
|   |   \--- src
|   |       +--- approval_mode_cli_arg.rs
|   |       +--- approval_presets.rs
|   |       +--- config_override.rs
|   |       +--- config_summary.rs
|   |       +--- elapsed.rs
|   |       +--- fuzzy_match.rs
|   |       +--- lib.rs
|   |       +--- mcp_impl_cli_arg.rs
|   |       +--- model_presets.rs
|   |       +--- sandbox_mode_cli_arg.rs
|   |       \--- sandbox_summary.rs
|   +--- config.md
|   +--- core
|   |   +--- Cargo.toml
|   |   +--- prompt.md
|   |   +--- README.md
|   |   +--- src
|   |   |   +--- apply_patch.rs
|   |   |   +--- auth.rs
|   |   |   +--- bash.rs
|   |   |   +--- chat_completions.rs
|   |   |   +--- client.rs
|   |   |   +--- client_common.rs
|   |   |   +--- codex.rs
|   |   |   +--- codex_conversation.rs
|   |   |   +--- config.rs
|   |   |   +--- config_edit.rs
|   |   |   +--- config_profile.rs
|   |   |   +--- config_types.rs
|   |   |   +--- conversation_history.rs
|   |   |   +--- conversation_manager.rs
|   |   |   +--- custom_prompts.rs
|   |   |   +--- default_client.rs
|   |   |   +--- environment_context.rs
|   |   |   +--- error.rs
|   |   |   +--- event_mapping.rs
|   |   |   +--- exec.rs
|   |   |   +--- exec_command
|   |   |   |   +--- exec_command_params.rs
|   |   |   |   +--- exec_command_session.rs
|   |   |   |   +--- mod.rs
|   |   |   |   +--- responses_api.rs
|   |   |   |   +--- session_id.rs
|   |   |   |   \--- session_manager.rs
|   |   |   +--- exec_env.rs
|   |   |   +--- flags.rs
|   |   |   +--- git_info.rs
|   |   |   +--- is_safe_command.rs
|   |   |   +--- landlock.rs
|   |   |   +--- lib.rs
|   |   |   +--- mcp_connection_manager.rs
|   |   |   +--- mcp_tool_call.rs
|   |   |   +--- message_history.rs
|   |   |   +--- model_family.rs
|   |   |   +--- model_provider_info.rs
|   |   |   +--- openai_model_info.rs
|   |   |   +--- openai_tools.rs
|   |   |   +--- parse_command.rs
|   |   |   +--- plan_tool.rs
|   |   |   +--- project_doc.rs
|   |   |   +--- prompt_for_compact_command.md
|   |   |   +--- rollout
|   |   |   |   +--- list.rs
|   |   |   |   +--- mod.rs
|   |   |   |   +--- policy.rs
|   |   |   |   +--- recorder.rs
|   |   |   |   \--- tests.rs
|   |   |   +--- safety.rs
|   |   |   +--- seatbelt.rs
|   |   |   +--- seatbelt_base_policy.sbpl
|   |   |   +--- shell.rs
|   |   |   +--- spawn.rs
|   |   |   +--- terminal.rs
|   |   |   +--- token_data.rs
|   |   |   +--- tool_apply_patch.lark
|   |   |   +--- tool_apply_patch.rs
|   |   |   +--- truncate.rs
|   |   |   +--- turn_diff_tracker.rs
|   |   |   +--- unified_exec
|   |   |   |   +--- errors.rs
|   |   |   |   \--- mod.rs
|   |   |   +--- user_instructions.rs
|   |   |   +--- user_notification.rs
|   |   |   \--- util.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       +--- chat_completions_payload.rs
|   |       +--- chat_completions_sse.rs
|   |       +--- cli_responses_fixture.sse
|   |       +--- common
|   |       |   +--- Cargo.toml
|   |       |   \--- lib.rs
|   |       +--- fixtures
|   |       |   +--- completed_template.json
|   |       |   \--- incomplete_sse.json
|   |       \--- suite
|   |           +--- cli_stream.rs
|   |           +--- client.rs
|   |           +--- compact.rs
|   |           +--- exec.rs
|   |           +--- exec_stream_events.rs
|   |           +--- fork_conversation.rs
|   |           +--- live_cli.rs
|   |           +--- mod.rs
|   |           +--- prompt_caching.rs
|   |           +--- seatbelt.rs
|   |           +--- stream_error_allows_next_turn.rs
|   |           \--- stream_no_completed.rs
|   +--- default.nix
|   +--- docs
|   |   \--- protocol_v1.md
|   +--- exec
|   |   +--- Cargo.toml
|   |   +--- src
|   |   |   +--- cli.rs
|   |   |   +--- event_processor.rs
|   |   |   +--- event_processor_with_human_output.rs
|   |   |   +--- event_processor_with_json_output.rs
|   |   |   +--- lib.rs
|   |   |   \--- main.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       +--- fixtures
|   |       |   +--- apply_patch_freeform_final.txt
|   |       |   +--- sse_apply_patch_add.json
|   |       |   +--- sse_apply_patch_freeform_add.json
|   |       |   +--- sse_apply_patch_freeform_update.json
|   |       |   +--- sse_apply_patch_update.json
|   |       |   \--- sse_response_completed.json
|   |       \--- suite
|   |           +--- apply_patch.rs
|   |           +--- common.rs
|   |           +--- mod.rs
|   |           \--- sandbox.rs
|   +--- execpolicy
|   |   +--- build.rs
|   |   +--- Cargo.toml
|   |   +--- README.md
|   |   +--- src
|   |   |   +--- arg_matcher.rs
|   |   |   +--- arg_resolver.rs
|   |   |   +--- arg_type.rs
|   |   |   +--- default.policy
|   |   |   +--- error.rs
|   |   |   +--- exec_call.rs
|   |   |   +--- execv_checker.rs
|   |   |   +--- lib.rs
|   |   |   +--- main.rs
|   |   |   +--- opt.rs
|   |   |   +--- policy.rs
|   |   |   +--- policy_parser.rs
|   |   |   +--- program.rs
|   |   |   +--- sed_command.rs
|   |   |   \--- valid_exec.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       \--- suite
|   |           +--- bad.rs
|   |           +--- cp.rs
|   |           +--- good.rs
|   |           +--- head.rs
|   |           +--- literal.rs
|   |           +--- ls.rs
|   |           +--- mod.rs
|   |           +--- parse_sed_command.rs
|   |           +--- pwd.rs
|   |           \--- sed.rs
|   +--- file-search
|   |   +--- Cargo.toml
|   |   +--- README.md
|   |   \--- src
|   |       +--- cli.rs
|   |       +--- lib.rs
|   |       \--- main.rs
|   +--- justfile
|   +--- linux-sandbox
|   |   +--- Cargo.toml
|   |   +--- README.md
|   |   +--- src
|   |   |   +--- landlock.rs
|   |   |   +--- lib.rs
|   |   |   +--- linux_run_main.rs
|   |   |   \--- main.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       \--- suite
|   |           +--- landlock.rs
|   |           \--- mod.rs
|   +--- login
|   |   +--- Cargo.toml
|   |   +--- src
|   |   |   +--- assets
|   |   |   |   \--- success.html
|   |   |   +--- lib.rs
|   |   |   +--- pkce.rs
|   |   |   \--- server.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       \--- suite
|   |           +--- login_server_e2e.rs
|   |           \--- mod.rs
|   +--- mcp-client
|   |   +--- Cargo.toml
|   |   +--- src
|   |   |   +--- lib.rs
|   |   |   +--- main.rs
|   |   |   +--- mcp_client.rs
|   |   |   \--- rmcp_wrapper.rs
|   |   \--- tests
|   |       \--- official_list.rs
|   +--- mcp-server
|   |   +--- Cargo.toml
|   |   +--- Cargo.toml.bak
|   |   +--- src
|   |   |   +--- codex_message_processor.rs
|   |   |   +--- codex_tool_config.rs
|   |   |   +--- codex_tool_runner.rs
|   |   |   +--- error_code.rs
|   |   |   +--- exec_approval.rs
|   |   |   +--- json_to_toml.rs
|   |   |   +--- lib.rs
|   |   |   +--- main.rs
|   |   |   +--- message_processor.rs
|   |   |   +--- outgoing_message.rs
|   |   |   +--- patch_approval.rs
|   |   |   +--- rmcp_handlers.rs
|   |   |   \--- tool_handlers
|   |   |       \--- mod.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       +--- common
|   |       |   +--- Cargo.toml
|   |       |   +--- lib.rs
|   |       |   +--- mcp_process.rs
|   |       |   +--- mock_model_server.rs
|   |       |   +--- README.md
|   |       |   +--- responses.rs
|   |       |   \--- shell.rs
|   |       \--- suite
|   |           +--- archive_conversation.rs
|   |           +--- auth.rs
|   |           +--- codex_message_processor_flow.rs
|   |           +--- codex_tool.rs
|   |           +--- config.rs
|   |           +--- create_conversation.rs
|   |           +--- interrupt.rs
|   |           +--- list_resume.rs
|   |           +--- login.rs
|   |           +--- mod.rs
|   |           +--- parity.rs
|   |           +--- send_message.rs
|   |           +--- user_agent.rs
|   |           \--- user_info.rs
|   +--- mcp-types
|   |   +--- Cargo.toml
|   |   +--- check_lib_rs.py
|   |   +--- generate_mcp_types.py
|   |   +--- README.md
|   |   +--- schema
|   |   |   +--- 2025-03-26
|   |   |   |   \--- schema.json
|   |   |   \--- 2025-06-18
|   |   |       \--- schema.json
|   |   +--- src
|   |   |   \--- lib.rs
|   |   \--- tests
|   |       +--- all.rs
|   |       \--- suite
|   |           +--- initialize.rs
|   |           +--- mod.rs
|   |           \--- progress_notification.rs
|   +--- ollama
|   |   +--- Cargo.toml
|   |   \--- src
|   |       +--- client.rs
|   |       +--- lib.rs
|   |       +--- parser.rs
|   |       +--- pull.rs
|   |       \--- url.rs
|   +--- protocol
|   |   +--- Cargo.toml
|   |   +--- README.md
|   |   \--- src
|   |       +--- config_types.rs
|   |       +--- custom_prompts.rs
|   |       +--- lib.rs
|   |       +--- mcp_protocol.rs
|   |       +--- message_history.rs
|   |       +--- models.rs
|   |       +--- num_format.rs
|   |       +--- parse_command.rs
|   |       +--- plan_tool.rs
|   |       \--- protocol.rs
|   +--- protocol-ts
|   |   +--- Cargo.toml
|   |   +--- generate-ts
|   |   \--- src
|   |       +--- lib.rs
|   |       \--- main.rs
|   +--- README.md
|   +--- rustfmt.toml
|   +--- rust-toolchain.toml
|   +--- scripts
|   |   \--- create_github_release
|   +--- target
|   \--- tui
|       +--- Cargo.toml
|       +--- prompt_for_init_command.md
|       +--- src
|       |   +--- app.rs
|       |   +--- app_backtrack.rs
|       |   +--- app_event.rs
|       |   +--- app_event_sender.rs
|       |   +--- backtrack_helpers.rs
|       |   +--- bin
|       |   |   \--- md-events.rs
|       |   +--- bottom_pane
|       |   |   +--- approval_modal_view.rs
|       |   |   +--- bottom_pane_view.rs
|       |   |   +--- chat_composer.rs
|       |   |   +--- chat_composer_history.rs
|       |   |   +--- command_popup.rs
|       |   |   +--- file_search_popup.rs
|       |   |   +--- list_selection_view.rs
|       |   |   +--- mod.rs
|       |   |   +--- paste_burst.rs
|       |   |   +--- popup_consts.rs
|       |   |   +--- scroll_state.rs
|       |   |   +--- selection_popup_common.rs
|       |   |   +--- snapshots
|       |   |   |   +--- codex_tui__bottom_pane__chat_composer__tests__backspace_after_pastes.snap
|       |   |   |   +--- codex_tui__bottom_pane__chat_composer__tests__empty.snap
|       |   |   |   +--- codex_tui__bottom_pane__chat_composer__tests__large.snap
|       |   |   |   +--- codex_tui__bottom_pane__chat_composer__tests__multiple_pastes.snap
|       |   |   |   +--- codex_tui__bottom_pane__chat_composer__tests__slash_popup_mo.snap
|       |   |   |   \--- codex_tui__bottom_pane__chat_composer__tests__small.snap
|       |   |   \--- textarea.rs
|       |   +--- chatwidget
|       |   |   +--- agent.rs
|       |   |   +--- interrupts.rs
|       |   |   +--- snapshots
|       |   |   |   +--- codex_tui__chatwidget__tests__apply_patch_manual_flow_history_approved.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__apply_patch_manual_flow_history_proposed.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__approval_modal_exec.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__approval_modal_exec_no_reason.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__approval_modal_patch.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__binary_size_ideal_response.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__chat_small_idle_h1.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__chat_small_idle_h2.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__chat_small_idle_h3.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__chat_small_running_h1.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__chat_small_running_h2.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__chat_small_running_h3.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__chatwidget_exec_and_status_layout_vt100_snapshot.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__chatwidget_markdown_code_blocks_vt100_snapshot.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__deltas_then_same_final_message_are_rendered_snapshot.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__disabled_slash_command_while_task_running_snapshot.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exec_approval_history_decision_aborted_long.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exec_approval_history_decision_aborted_multiline.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exec_approval_history_decision_approved_short.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exec_approval_history_proposed_multiline.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exec_approval_history_proposed_short.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exploring_step1_start_ls.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exploring_step2_finish_ls.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exploring_step3_start_cat_foo.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exploring_step4_finish_cat_foo.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exploring_step5_finish_sed_range.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__exploring_step6_finish_cat_bar.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__final_reasoning_then_message_without_deltas_are_rendered.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__interrupt_exec_marks_failed.snap
|       |   |   |   +--- codex_tui__chatwidget__tests__status_widget_active.snap
|       |   |   |   \--- codex_tui__chatwidget__tests__status_widget_and_approval_modal.snap
|       |   |   \--- tests.rs
|       |   +--- chatwidget.rs
|       |   +--- citation_regex.rs
|       |   +--- cli.rs
|       |   +--- clipboard_paste.rs
|       |   +--- custom_terminal.rs
|       |   +--- diff_render.rs
|       |   +--- exec_command.rs
|       |   +--- file_search.rs
|       |   +--- get_git_diff.rs
|       |   +--- history_cell.rs
|       |   +--- insert_history.rs
|       |   +--- key_hint.rs
|       |   +--- lib.rs
|       |   +--- live_wrap.rs
|       |   +--- main.rs
|       |   +--- markdown.rs
|       |   +--- markdown_render.rs
|       |   +--- markdown_render_tests.rs
|       |   +--- markdown_stream.rs
|       |   +--- onboarding
|       |   |   +--- auth.rs
|       |   |   +--- mod.rs
|       |   |   +--- onboarding_screen.rs
|       |   |   +--- trust_directory.rs
|       |   |   \--- welcome.rs
|       |   +--- pager_overlay.rs
|       |   +--- render
|       |   |   +--- highlight.rs
|       |   |   +--- line_utils.rs
|       |   |   \--- mod.rs
|       |   +--- resume_picker.rs
|       |   +--- session_log.rs
|       |   +--- shimmer.rs
|       |   +--- slash_command.rs
|       |   +--- snapshots
|       |   |   +--- codex_tui__diff_render__tests__add_details.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_add_block.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_delete_block.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_multiple_files_block.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_update_block.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_update_block_manual.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_update_block_relativizes_path.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_update_block_wraps_long_lines.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_update_block_wraps_long_lines_text.snap
|       |   |   +--- codex_tui__diff_render__tests__apply_update_with_rename_block.snap
|       |   |   +--- codex_tui__diff_render__tests__blank_context_line.snap
|       |   |   +--- codex_tui__diff_render__tests__single_line_replacement_counts.snap
|       |   |   +--- codex_tui__diff_render__tests__update_details_with_rename.snap
|       |   |   +--- codex_tui__diff_render__tests__vertical_ellipsis_between_hunks.snap
|       |   |   +--- codex_tui__diff_render__tests__wrap_behavior_insert.snap
|       |   |   +--- codex_tui__history_cell__tests__coalesced_reads_dedupe_names.snap
|       |   |   +--- codex_tui__history_cell__tests__coalesces_reads_across_multiple_calls.snap
|       |   |   +--- codex_tui__history_cell__tests__coalesces_sequential_reads_within_one_call.snap
|       |   |   +--- codex_tui__history_cell__tests__multiline_command_both_lines_wrap_with_correct_prefixes.snap
|       |   |   +--- codex_tui__history_cell__tests__multiline_command_without_wrap_uses_branch_then_eight_spaces.snap
|       |   |   +--- codex_tui__history_cell__tests__multiline_command_wraps_with_extra_indent_on_subsequent_lines.snap
|       |   |   +--- codex_tui__history_cell__tests__plan_update_with_note_and_wrapping_snapshot.snap
|       |   |   +--- codex_tui__history_cell__tests__plan_update_without_note_snapshot.snap
|       |   |   +--- codex_tui__history_cell__tests__ran_cell_multiline_with_stderr_snapshot.snap
|       |   |   +--- codex_tui__history_cell__tests__single_line_command_compact_when_fits.snap
|       |   |   +--- codex_tui__history_cell__tests__single_line_command_wraps_with_four_space_continuation.snap
|       |   |   +--- codex_tui__history_cell__tests__stderr_tail_more_than_five_lines_snapshot.snap
|       |   |   +--- codex_tui__history_cell__tests__user_history_cell_wraps_and_prefixes_each_line_snapshot.snap
|       |   |   +--- codex_tui__markdown_render__markdown_render_tests__markdown_render_complex_snapshot.snap
|       |   |   +--- codex_tui__pager_overlay__tests__static_overlay_snapshot_basic.snap
|       |   |   +--- codex_tui__pager_overlay__tests__transcript_overlay_snapshot_basic.snap
|       |   |   +--- codex_tui__status_indicator_widget__tests__renders_truncated.snap
|       |   |   +--- codex_tui__status_indicator_widget__tests__renders_with_queued_messages.snap
|       |   |   \--- codex_tui__status_indicator_widget__tests__renders_with_working_header.snap
|       |   +--- status_indicator_widget.rs
|       |   +--- streaming
|       |   |   +--- controller.rs
|       |   |   \--- mod.rs
|       |   +--- text_formatting.rs
|       |   +--- tui.rs
|       |   +--- updates.rs
|       |   +--- user_approval_widget.rs
|       |   +--- version.rs
|       |   \--- wrapping.rs
|       +--- styles.md
|       \--- tests
|           +--- all.rs
|           +--- fixtures
|           |   +--- binary-size-log.jsonl
|           |   \--- oss-story.jsonl
|           \--- suite
|               +--- mod.rs
|               +--- status_indicator.rs
|               +--- vt100_history.rs
|               +--- vt100_live_commit.rs
|               \--- vt100_streaming_no_dup.rs
+--- docs
|   +--- advanced.md
|   +--- authentication.md
|   +--- CLA.md
|   +--- config.md
|   +--- contributing.md
|   +--- experimental.md
|   +--- faq.md
|   +--- getting-started.md
|   +--- install.md
|   +--- license.md
|   +--- open-source-fund.md
|   +--- platform-sandboxing.md
|   +--- prompts.md
|   +--- release_management.md
|   +--- sandbox.md
|   \--- zdr.md
+--- filefoldertree.md
+--- flake.lock
+--- flake.nix
+--- LICENSE
+--- NOTICE
+--- package.json
+--- Pack-CodexArtifacts.ps1
+--- PNPM.md
+--- pnpm-lock.yaml
+--- pnpm-workspace.yaml
+--- README.md
\--- scripts
    +--- asciicheck.py
    +--- publish_to_npm.py
    \--- readme_toc.py
